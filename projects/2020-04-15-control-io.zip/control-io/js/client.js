
//Web JS Project that implements THREE.js.
//Literally based off of tutorial:
//https://threejs.org/docs/index.html#manual/en/introduction/Creating-a-scene



console.log("[Control.IO] Loaded client module.")
var clientType = navigator.userAgent;

console.log(clientType);
//contact server to generate session id

//all post-setup actions below here
var game;
window.onload = function() {
    game = new Game();
}
