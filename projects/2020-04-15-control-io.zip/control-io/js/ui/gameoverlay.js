class GameOverlay {
    
}