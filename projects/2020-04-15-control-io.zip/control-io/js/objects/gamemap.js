class GameMap {
    constructor(settings) {
        console.log(settings);
    }
}