function PlayerObject(gamewindow, x, y, color) {
    // this.gamewindow = gamewindow;

    this.assetgroup = new paper.Group();
    this.assetgroup.applyMatrix = false;

    this.assetgroup.position.x = x;
    this.assetgroup.position.y = y;

    this.spritegroup = new paper.Group({
        applyMatrix: false,
        // clipped: true
    });

    // var tinycolorval = tinycolor(color).toRgb();
    // console.log(tinycolorval);
    // console.log(konvaimg);

    this.spriteimg = new paper.Raster({
        source: '../img/grey.png',
        point: [0, 0],
        scaling: 0.1,
        applyMatrix: false,
        width: this.width,
        height: this.height,
        visible: false
    });

    this.spritemask = new paper.Path.Rectangle({
        size: [60, 60],
        fillColor: color,
        position: [this.spritegroup.position.x/2, this.spritegroup.position.y/2],
        blendMode: 'color',
        applyMatrix: false,
        clipped: true
    });
    // this.spritemask_r = this.spritemask.rasterize();
    // this.spritemask_r.point = [0, 0];

    var url = '../img/playersprite01.svg';
    
    // var sprite;
    this.spritesvg = new paper.Group();
    this.spritesvg.applyMatrix = false;
    this.spritegroup.importSVG(url, function(item) {
        // console.log(item);
        // sprite = item;
        this.strokeWidth = 2;
    });
    // this.spritegroup.children[0].scaling = 0.15;
    // this.spritegroup.children[0].position = [-45, -45]
    // this.spritesvg.blendMode = "source-over"
    // this.spritesvg.center = [0, 0]

    console.log(this.spritesvg)
    // console.log(this.spritesvg.height)

    // paper.project.importSVG(url, function(item) {
    //     console.log(item);
    //     sprite = item;
    // });
    // // setTimeout(() => { console.log("Waiting!"); }, 2000);

    // console.log(paper.project.firstChild);
    // console.log(paper.project.lastChild);

    // this.spritesvg.children[0].position = [0, 0]
    // this.spritesvg.children[0].scale(0.15);
    // this.spritesvg.children[0].strokeWidth = 2;
    // this.spritesvg.children[0].applyMatrix = false;



    // var this.spritesvg;
    // paper.project.importSVG(url, function(item) {
    //     this.spritesvg = item
    //     this.spritesvg.name = "playersprite01";
    //     this.spritesvg.scale(0.15)
    //     this.spritesvg.strokeWidth = 2;
    //     this.spritesvg.applyMatrix = false;
    // });
    // console.log(paper.project.activeLayer.children);
    // // this.spritesvg = paper.project.getItem("playersprite01");
    // // this.spritesvg = paper.project.activeLayer.children["playersprite01"];
    // // this.spritesvg = paper.project.activeLayer.children.getItem("playersprite01");
    // // this.spritesvg = paper.project.activeLayer.getItem("playersprite01");

    // this.spritesvg.position = new paper.Point(this.spritegroup.position.x, this.spritegroup.position.y);

    this.spritegroup.clipped = true;
    this.spriteimg.clipMask = true;

    // this.spritegroup.addChild(this.spriteimg);
    // this.spritegroup.addChild(this.spritesvg);
    this.spritegroup.addChild(this.spritemask);

    this.spritegroup.addChild(new paper.Path());

    // console.log(this.spritesvg.getItem(this.spritesvg));
    // console.log(this.spritesvg.firstChild);
    console.log(this.spritegroup.children[1]);
    this.spritegroup.children[1].applyMatrix = false;
    this.spritegroup.children[1].strokeWidth = 2;
    // this.spritegroup.children[1].scale(0.15, 0.15, [-45, -4]);
    this.spritegroup.children[1].position = [0, 0]
    this.spritegroup.children[1].scale(0.15);
    // this.spritegroup.children[0].size = 
    // console.log(this.spritesvg.children[0]);
    // console.log(this.spritesvg.children["0"]);

    // this.spritegroup.importSVG('../img/playersprite01.svg');

    // this.spritegroup.children = [this.spritemask];
    // this.spritegroup.children = [this.spritesvg, this.spritemask];
    // this.spritegroup.children = [this.spriteimg, this.spritesvg, this.spritemask];
    // this.spritegroup.children = [this.spriteimg, this.spritemask, this.spritesvg];
    this.spritegroup.blendMode = "source-over";
    // this.spritegroup.addChild(this.spritemask_r);

    this.assetgroup.addChild(this.spritegroup);

    gamewindow.layers["players"].addChild(this.assetgroup);

    function rotate(angle) {
        this.spritegroup.rotation = angle;
    }

    function move(xpos, ypos) {
        this.assetgroup.position.x = xpos;
        this.assetgroup.position.y = ypos;
    }

    return {
        rotate: rotate,
        move: move,
        assetgroup: this.assetgroup,
        spritegroup: this.spritegroup,
        // spriteimg: this.spriteimg,
        // spritemask: this.spritemask,
    }
}

/*
 * A coordinate that a player can create.
 */
function PlayerCoordinate(gamewindow, x, y, color) {
    // constructor (gamewindow, x, y, color) {
    this.x = x;
    this.y = y;

    this.asset = new paper.Path.Circle({
        center: [x, y],
        radius: 8,
        fillColor: color
    });

    gamewindow.layers["playersetlines"].addChild(this.asset);
    // }

    return {
        x: this.x,
        y: this.y,
        asset: this.asset
    }
}

/*
* A line joining two coordinates.
*/
class PlayerCoordinateLine {
    constructor (gamewindow, x1, y1, x2, y2, color) {

        this.asset = new paper.Path.Line(new paper.Point(x1, y1), new paper.Point(x2, y2));
        this.asset.strokeColor = color;
        this.asset.strokeWidth = lineWidth;
        this.asset.strokeCap = 'round';
        gamewindow.layers["playersetlines"].addChild(this.asset);
    }
}

/*
 * A guiding line that follows the player, showing where the next face of their polygon will be.
 */
class PlayerGuidingLine {
    constructor (gamewindow, x1, y1, x2, y2, color) {

        this.asset = new paper.Path.Line(new paper.Point(x1, y1), new paper.Point(x2, y2));
        this.asset.strokeColor = color;
        this.asset.strokeWidth = lineWidth;
        this.asset.strokeCap = 'round';
        this.asset.dashArray = [4, 10]
        gamewindow.layers["playerguidinglines"].addChild(this.asset);
    }
}

/*
 * A polygon that a 
 */
class PlayerPolygon {
    constructor (gamewindow, coordsArray, color) {

        this.asset = new paper.Path();
        var i = 0;
        while (i < coordsArray.length) {
            // this.polygonShape.lineTo(coordsArray[i].x, coordsArray[i].y);
            this.asset.add(new paper.Point(coordsArray[i].x, coordsArray[i].y));
            i++;
        }
        this.asset.closed = true;
        this.asset.fillColor = color;
        gamewindow.layers["shapes"].addChild(this.asset);

        console.log(Math.abs(this.asset.area));
        // gamewindow.layers["shaperaster"]
    }
}